import yaml
from iba.education.utils.s3 import S3


class Config:
    def __init__(self, key, bucket='iba-gomel-useast1-aws-edu-assets'):
        self.bucket = bucket
        self.key = key

    def get(self):
        return yaml.safe_load(S3().get_object(self.bucket, self.key))
