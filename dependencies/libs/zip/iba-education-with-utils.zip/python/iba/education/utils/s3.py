import boto3


class S3:
    session = boto3.session.Session()

    def __init__(self):
        self.client = self.session.client(service_name='s3')
        self.resource = self.session.resource(service_name='s3')

    def get_object(self, bucket, key, decode='utf-8'):
        return self.client.get_object(Bucket=bucket, Key=key)['Body'].read().decode(decode)

